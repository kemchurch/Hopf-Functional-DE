function df = D2D1f_at_exp_times_hv(X,c,h,M,omega,v) 
df = [0;1]*v;
end